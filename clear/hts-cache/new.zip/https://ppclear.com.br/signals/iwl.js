<!DOCTYPE html><html lang="en" data-astro-cid-sckkx6r4> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><link rel="icon" type="image/svg+xml" href="/faviconppkare.png"><meta name="generator" content="Astro v5.13.11"><title>PPClear</title><script type="text/javascript">
      (function (c, l, a, r, i, t, y) {
        c[a] =
          c[a] ||
          function () {
            (c[a].q = c[a].q || []).push(arguments);
          };
        t = l.createElement(r);
        t.async = 1;
        t.src = "https://www.clarity.ms/tag/" + i;
        y = l.getElementsByTagName(r)[0];
        y.parentNode.insertBefore(t, y);
      })(window, document, "clarity", "script", "tjwcs7ysni");
    </script><script>
      document.addEventListener("DOMContentLoaded", function () {
        function getCookie(name) {
          const cookies = document.cookie.split(";");
          for (let cookie of cookies) {
            const [key, value] = cookie.trim().split("=");
            if (key === name) {
              return value;
            }
          }
          return null;
        }

        function generateUUID() {
          return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (c) {
              const r = (Math.random() * 16) | 0,
                v = c === "x" ? r : (r & 0x3) | 0x8;
              return v.toString(16);
            }
          );
        }

        // async function sendEvent(eventType, data = {}) {
        //   const contentName = "ppkare";
        //   const contentId = "ppkare";
        //   const eventId = generateUUID();

        //   const customEvents = [
        //     "Scroll_25",
        //     "Scroll_50",
        //     "Scroll_75",
        //     "Scroll_90",
        //     "Timer_1min",
        //     "PlayVideo",
        //     "ViewVideo_25",
        //     "ViewVideo_50",
        //     "ViewVideo_75",
        //     "ViewVideo_90",
        //   ];
        //   const specialEvents = ["AddToCart", "InitiateCheckout", "Lead"];

        //   if (specialEvents.includes(eventType)) {
        //     updateUserDataFromForm();
        //   }

        //   const _customData = {
        //     content_name: contentName,
        //     content_ids: contentId,
        //     ...(specialEvents.includes(eventType) && {
        //       value: data.value || 0,
        //       currency: data.currency || "BRL",
        //     }),
        //   };

        //   const _userData = { eventID: eventId, ...userData };

        //   if (
        //     eventType !== "Init" &&
        //     eventType !== "UpdateUserData" &&
        //     !customEvents.includes(eventType)
        //   ) {
        //     fbq("track", eventType, _customData, _userData);
        //   } else if (eventType !== "Init" && eventType !== "UpdateUserData") {
        //     fbq("trackCustom", eventType, _customData, _userData);
        //   }

        //   try {
        //     const URL = window.location.href;
        //     const payload = {
        //       userId,
        //       contentName,
        //       contentId,
        //       eventType,
        //       eventId,
        //       URL,
        //       fbc: data.fbc || userData.fbc || null,
        //       fbp: data.fbp || userData.fbp || null,
        //       fn: userData.fn || null,
        //       ln: userData.ln || null,
        //       em: userData.em || null,
        //       ph: userData.ph || null,
        //     };
        //     const response = await fetch(
        //       "https://api.ppkare.com.br/events/send",
        //       {
        //         method: "POST",
        //         credentials: "include",
        //         headers: {
        //           "Content-Type": "application/json",
        //         },
        //         body: JSON.stringify(payload),
        //       }
        //     );
        //     if (eventType == "Init") {
        //       const responseData = await response.json();
        //       return responseData;
        //     }
        //   } catch (e) {
        //     console.error(`Erro ao rastrear evento de ${eventType}:`, e);
        //   }
        // }

        async function sendEvent(eventType, data = {}) {
          const contentName = "ppkare";
          const contentId = "ppkare";
          const eventId = generateUUID();

          const customEvents = [
            "Scroll_25",
            "Scroll_50",
            "Scroll_75",
            "Scroll_90",
            "Timer_1min",
            "PlayVideo",
            "ViewVideo_25",
            "ViewVideo_50",
            "ViewVideo_75",
            "ViewVideo_90",
          ];
          const specialEvents = ["AddToCart", "InitiateCheckout", "Lead"];

          if (specialEvents.includes(eventType)) {
            updateUserDataFromForm();
          }

          const _customData = {
            content_name: contentName,
            content_ids: contentId,
            ...(specialEvents.includes(eventType) && {
              value: data.value || 0,
              currency: data.currency || "BRL",
            }),
          };

          const _userData = { eventID: eventId, ...userData };

          if (
            eventType !== "Init" &&
            eventType !== "UpdateUserData" &&
            !customEvents.includes(eventType)
          ) {
            fbq("track", eventType, _customData, _userData);
          } else if (eventType !== "Init" && eventType !== "UpdateUserData") {
            fbq("trackCustom", eventType, _customData, _userData);
          }

          const URL = window.location.href;
          const payload = {
            userId,
            contentName,
            contentId,
            eventType,
            eventId,
            URL,
            fbc: data.fbc || userData.fbc || null,
            fbp: data.fbp || userData.fbp || null,
            fn: userData.fn || null,
            ln: userData.ln || null,
            em: userData.em || null,
            ph: userData.ph || null,
          };

          // detecta se é WebKit (Safari, iOS, iPadOS ou InApp WebView)
          const isWebKit =
            /AppleWebKit/i.test(navigator.userAgent) &&
            !/Chrome/i.test(navigator.userAgent);

          try {
            // 🔹 se for InitiateCheckout em WebKit, envia direto pelo Worker
            if (eventType === "InitiateCheckout" && isWebKit) {
              // console.log(
              //   "[sendEvent] Safari detectado — enviando InitiateCheckout via Worker fallback"
              // );
              await sendEventViaWorker(payload);
              return;
            }

            // 🔹 caso contrário, tenta envio direto
            const response = await fetch(
              "https://api.serumintimo.com.br/events/send",
              {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
              },
            );

            if (response.ok) {
              if (eventType === "Init") {
                const responseData = await response.json();
                return responseData;
              }
              return true;
            }

            // 🔹 fallback se a API falhar
            if (!response.ok && response.status >= 500) {
              await sendEventViaWorker(payload);
            }
          } catch (e) {
            await sendEventViaWorker(payload);
          }
        }

        // 🔄 Envia evento via Worker (rota /pixel)
        async function sendEventViaWorker(payload) {
          try {
            const params = new URLSearchParams(payload).toString();
            const workerUrl = `${window.location.origin}/pixel?${params}`;
            const res = await fetch(workerUrl, {
              method: "GET",
              mode: "no-cors",
            });
          } catch (e) {}
        }

        window.sendEvent = sendEvent;

        function updateUserDataFromForm() {
          let names, fn, ln, em, ph;
          names =
            document
              .querySelector('[name="NOME"]')
              ?.value.trim()
              .toLowerCase() || "";
          em =
            document
              .querySelector('[name="EMAIL"]')
              ?.value.trim()
              .toLowerCase() || "";
          ph =
            document
              .querySelector('[name="TELEFONE"]')
              ?.value.replace(/\s|-/g, "") || "";
          const surnameField = document.querySelector('[name="SOBRENOME"]');
          if (surnameField) {
            fn = names;
            ln = surnameField.value.trim().toLowerCase() || "";
          } else {
            const nameParts = names.split(" ");
            fn = nameParts[0] || "";
            ln = nameParts.length > 1 ? nameParts[nameParts.length - 1] : "";
          }

          const date = new Date();
          date.setFullYear(date.getFullYear() + 100);
          const expires = `expires=${date.toUTCString()}; path=/; domain=.${window.location.hostname.replace(/^www\./, "").split(".").slice(-2).join(".")}`;
          document.cookie = `fn=${fn}; ${expires}`;
          document.cookie = `ln=${ln}; ${expires}`;
          document.cookie = `em=${em}; ${expires}`;
          document.cookie = `ph=${ph.replace(/%20/g, "")}; ${expires}`;

          userData = {
            ...userData,
            ...(fn && { fn }),
            ...(ln && { ln }),
            ...(em && { em }),
            ...(ph && { ph }),
          };
        }

        let userData = {};
        let [userId, fbc, fbp, fn, ln, em, ph] = [
          "userId",
          "_fbc",
          "_fbp",
          "fn",
          "ln",
          "em",
          "ph",
        ].map(getCookie);

        if (!fbc) {
          const params = new URLSearchParams(window.location.search);
          const fbclid = params.get("fbclid");
          if (fbclid) {
            const timestamp = Date.now();
            fbc = `fb.1.${timestamp}.${fbclid}`;
            const date = new Date();
            date.setFullYear(date.getFullYear() + 100);
            const expires = `expires=${date.toUTCString()}; path=/; domain=.${window.location.hostname.replace(/^www\./, "").split(".").slice(-2).join(".")}`;
            document.cookie = `_fbc=${fbc}; ${expires}`;
          }
        }

        if (!fbp) {
          const creationTime = Date.now();
          const randomNumber = Math.floor(Math.random() * 1e10);
          fbp = `fb.1.${creationTime}.${randomNumber}`;

          const date = new Date();
          date.setFullYear(date.getFullYear() + 100);
          const expires = `expires=${date.toUTCString()}; path=/; domain=.${window.location.hostname.replace(/^www\./, "").split(".").slice(-2).join(".")}`;
          document.cookie = `_fbp=${fbp}; ${expires}`;
        }

        if (!userId) {
          userId = generateUUID();
          const date = new Date();
          date.setFullYear(date.getFullYear() + 100);
          document.cookie = `userId=${userId}; expires=${date.toUTCString()}; path=/;`;
        }

        (async () => {
          const data = (await sendEvent("Init")) || {};

          userData = {
            ...(data.ct && { ct: data.ct }),
            ...(data.st && { st: data.st }),
            ...(data.zp && { zp: data.zp }),
            ...(data.country && { country: data.country }),
            ...(data.client_ip_address && {
              client_ip_address: data.client_ip_address,
            }),
            ...(data.client_user_agent && {
              client_user_agent: data.client_user_agent,
            }),
            ...(data.fbc || fbc ? { fbc: data.fbc || fbc } : {}),
            ...(data.fbp || fbp ? { fbp: data.fbp || fbp } : {}),
            ...(userId && { external_id: userId }),
            ...(fn && { fn }),
            ...(ln && { ln }),
            ...(em && { em }),
            ...(ph && { ph }),
          };

          !(function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
              n.callMethod
                ? n.callMethod.apply(n, arguments)
                : n.queue.push(arguments);
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = "2.0";
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s);
          })(
            window,
            document,
            "script",
            "https://connect.facebook.net/en_US/fbevents.js"
          );
          fbq("init", "2099412367532155", userData);
          sendEvent("PageView");
          updateUserData();
        })();

        function updateUserData() {
          const checkInterval = 100;
          const maxWaitTime = 15000;
          let waited = 0;

          const interval = setInterval(() => {
            const fbc = getCookie("_fbc");
            const fbp = getCookie("_fbp");

            if (fbc || fbp) {
              clearInterval(interval);
              sendEvent("UpdateUserData", { userId, fbc, fbp });
            } else {
              waited += checkInterval;
              if (waited >= maxWaitTime) {
                clearInterval(interval);
              }
            }
          }, checkInterval);
        }

        // ================= SCRIPT 2: PAGAMENTO =================

        function getUrlParam(param) {
          const params = new URLSearchParams(window.location.search);
          return params.get(param);
        }

        function buildPaymentUrl(originalHref) {
          const userId = getCookie("userId");
          if (!userId) return originalHref;
          const domain = window.location.hostname.replace(/^www\./, "");
          const baseGenId = `${domain}|${userId}`;

          const paramsToPass = [
            "utm_source",
            "utm_medium",
            "utm_campaign",
            "utm_term",
            "utm_content",
            "fbclid",
            "fbc",
            "gclid",
            "ttclid",
            "wbraid",
            "sck",
            "referral",
            "_cid",
          ];

          function normalizeCidValue(input) {
            if (!input) return "";
            let v = String(input).trim();
            try {
              v = decodeURIComponent(v);
            } catch (e) {}
            v = v.replace(/^[\s\{]+/, "").replace(/[\s\}]+$/, "");
            return v ? `{${v}}` : "";
          }

          const url = new URL(originalHref, window.location.origin);

          // 1) Candidatos a _cid: (a) URL da página, (b) URL do href, (c) 3º split do gen_id já presente no href
          const rawCidFromPage = getUrlParam("_cid") || "";
          const rawCidFromHref = url.searchParams.get("_cid") || "";
          const existingHrefGenId = url.searchParams.get("gen_id") || "";

          let rawCidCandidate = rawCidFromPage || rawCidFromHref;
          if (!rawCidCandidate && existingHrefGenId) {
            const parts = existingHrefGenId.split("|");
            if (parts.length >= 3 && parts[2]) {
              rawCidCandidate = parts[2];
            } else {
              const m = existingHrefGenId.match(/\{([^}]+)\}/);
              if (m) rawCidCandidate = m[1];
            }
          }

          const cidNormalized = normalizeCidValue(rawCidCandidate);

          // 2) Monta gen_id final (sempre domain|userId, e se houver cid => domain|userId|{cid})
          const genId = cidNormalized
            ? `${baseGenId}|${cidNormalized}`
            : baseGenId;

          // 3) Aplica gen_id
          url.searchParams.set("gen_id", genId);

          // 4) Mantém seu comportamento original de src para não-Google
          const utmSource = getUrlParam("utm_source") || "";
          const isGoogle = utmSource.toLowerCase().includes("google");
          if (!isGoogle) {
            url.searchParams.set("src", genId);
          }

          // 5) Repassa parâmetros úteis (sem incluir _cid aqui; já acoplamos no gen_id)
          paramsToPass.forEach((param) => {
            const value = getUrlParam(param);
            if (value) url.searchParams.set(param, value);
          });

          return url.toString();
        }

        function bindPaymentLinks() {
          document
            .querySelectorAll(
              'a[href*="app.trivvo.com.br/payment"], a[href*="app.trivvo.com.br/d/payment"]'
            )
            .forEach((anchor) => {
              const originalHref = anchor.getAttribute("href");
              if (!originalHref) return;
              const updatedHref = buildPaymentUrl(originalHref);
              anchor.setAttribute("href", updatedHref);
              if (!anchor.id) {
                anchor.id = "InitiateCheckout";
              }
            });
        }

        document.body.addEventListener("click", function (e) {
          const anchor = e.target.closest(
            'a[href*="app.trivvo.com.br/payment"], a[href*="app.trivvo.com.br/d/payment"]'
          );
          if (anchor) {
            const updatedHref = buildPaymentUrl(anchor.getAttribute("href"));
            anchor.setAttribute("href", updatedHref);
            if (typeof sendEvent === "function") {
              sendEvent("InitiateCheckout");
              console.log("✅ Evento InitiateCheckout disparado");
            }
          }
        });

        setTimeout(bindPaymentLinks, 500);

        const observer = new MutationObserver(bindPaymentLinks);
        observer.observe(document.body, {
          childList: true,
          subtree: true,
        });
      });
    </script><meta name="description" content="Landing page criada com Astro e Tailwind CSS"><script>
      (function () {
        const isV3 = (k) => typeof k === "string" && /^v3_[\w-]+/.test(k);

        function getParam(url, param) {
          try {
            return new URL(url, location.href).searchParams.get(param);
          } catch {
            return null;
          }
        }

        // Captura e guarda o vtid quando aparecer no botão liberado pelo player
        const observer = new MutationObserver((records) => {
          for (const rec of records) {
            if (rec.type === "attributes" && rec.attributeName === "href") {
              const href = rec.target.getAttribute("href");
              const key = getParam(href, "vtid");
              if (isV3(key)) {
                console.log("[VTurb ConversionKey detectado]", key);
                localStorage.setItem("vturbConversionKey", key);
                window.vturbConversionKey = key;
              }
            }
          }
        });

        document.querySelectorAll("a[href*='vtid=']").forEach((a) => {
          observer.observe(a, { attributes: true, attributeFilter: ["href"] });
        });

        // Função auxiliar para injetar o vtid no checkout
        function injectVtid(href) {
          const vtid = localStorage.getItem("vturbConversionKey");
          if (!vtid) return href;
          try {
            const url = new URL(href, window.location.origin);
            if (!url.searchParams.has("vtid")) {
              url.searchParams.set("vtid", vtid);
            }
            return url.toString();
          } catch {
            return href;
          }
        }

        // Hooka sua função de checkout já existente
        const originalBuildPaymentUrl = window.buildPaymentUrl;
        window.buildPaymentUrl = function (originalHref) {
          let newHref = originalBuildPaymentUrl
            ? originalBuildPaymentUrl(originalHref)
            : originalHref;
          newHref = injectVtid(newHref);
          return newHref;
        };

        // console.log(
        //   "[VTurb Spy] ativo. Vai injetar vtid no checkout assim que liberar."
        // );
      })();
    </script><link rel="stylesheet" href="/_astro/index.DnyrJBAr.css">
<style>html,body{margin:0;width:100%;height:100%}
</style></head> <body data-astro-cid-sckkx6r4>  <!-- TOPBAR FIXA --><div class="fixed top-0 left-0 w-full z-50"> <!-- Barra rosa --> <div class="bg-pink-600 text-white text-center py-2 shadow-md"> <p class="text-sm md:text-base font-semibold tracking-wide">
⏰ OFERTA VÁLIDA SOMENTE HOJE
</p> </div> <!-- Prova social preta --> <div class="flex justify-center bg-transparent"> <span id="social-proof" class="inline-flex items-center rounded-b-2xl bg-black text-white px-4 py-1 text-xs md:text-sm shadow">
Eduarda de Recife acabou de comprar
</span> </div> </div> <!-- HERO --> <section id="hero" class="relative overflow-hidden bg-white pt-28 pb-16 md:pb-24"> <!-- BG --> <img src="/BG.png" alt="" aria-hidden="true" class="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none select-none -mt-21 md:-mt-35"> <!-- CONTEÚDO --> <div class="relative z-10 max-w-7xl mx-auto px-6 lg:px-8"> <!-- CARROSSEL --> <div class="-mt-3 relative select-none overflow-hidden"> <!-- Track --> <div id="carousel-track" class="flex gap-6 items-center will-change-transform"> <img src="/ppclear/carrossel1.webp" alt="PPKare 1" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel2.webp" alt="PPKare 2" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel3.webp" alt="PPKare 3" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel4.webp" alt="PPKare 4" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel5.webp" alt="PPKare 5" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel6.webp" alt="PPKare 6" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel7.webp" alt="PPKare 7" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> <img src="/ppclear/carrossel8.webp" alt="PPKare 8" class="w-52 md:w-72 rounded-xl shadow-md select-none pointer-events-none"> </div> <!-- Botões --> <button id="prev-btn" class="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/70 text-white p-2 rounded-r-md">
❮
</button> <button id="next-btn" class="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/70 text-white p-2 rounded-l-md">
❯
</button> </div> <!-- HEADLINE --> <div class="mt-8 text-center"> <h1 class="font-serif text-[22px] md:text-[34px] leading-tight font-bold text-[#ed2b75]">
PPClear: O Clareador Íntimo Nº1 do Brasil.<br class="hidden md:block">
Resultado visível em menos de 15 dias.
</h1> </div> <!-- PREÇO --> <div class="mt-15 flex justify-center"> <div class="text-center"> <p class="text-[12px] md:text-sm text-gray-500 mb-1 font-bold">
De R$ 297,00 por <span class="inline-block px-1 rounded bg-pink-700 text-white font-semibold text-[0.7rem]">-33,67%</span> </p> <div class="text-[48px] md:text-[66px] font-serif -mt-4 font-bold text-black/90">R$ 197,00</div> <p class="text-[12px] md:text-xs text-gray-700">(ou até 12x de R$ 19,78)</p> </div> </div> <!-- CTA --> <div class="mt-6 text-center"> <a href="#oferta" class="inline-block rounded-xl bg-[#ed2b75] text-white font-semibold
                text-lg md:text-2xl px-7 md:px-10 py-3 shadow-lg transition transform hover:scale-105">
QUERO CLAREAR MINHA PPK
</a> </div> </div> </section> <!-- Script: carrossel suave + setas + prova social --> <script>
(function(){
  const track = document.getElementById('carousel-track');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');

  if(track){
    // duplica itens para efeito infinito
    track.innerHTML += track.innerHTML;

    let pos = 0;
    let speed = window.innerWidth < 768 ? 0.6 : 0.3;
    let paused = false;

    function animate(){
      if(!paused){
        pos -= speed;
        if(pos <= -track.scrollWidth/2){ pos = 0; }
        if(pos > 0){ pos = -track.scrollWidth/2; }
        track.style.transform = `translateX(${pos}px)`;
      }
      requestAnimationFrame(animate);
    }
    animate();

    // Pausa ao hover/touch
    track.addEventListener('mouseenter', ()=> paused = true);
    track.addEventListener('mouseleave', ()=> paused = false);
    track.addEventListener('touchstart', ()=> paused = true, {passive:true});
    track.addEventListener('touchend', ()=> paused = false, {passive:true});

    // Setas manuais
    function move(dir){
      paused = true;
      const shift = (track.children[0].offsetWidth + 24) * dir;
      pos -= shift;
      if(pos <= -track.scrollWidth/2){ pos = 0; }
      if(pos > 0){ pos = -track.scrollWidth/2; }
      track.style.transform = `translateX(${pos}px)`;
      setTimeout(()=> paused = false, 1500);
    }
    prevBtn.addEventListener("click", ()=> move(-1));
    nextBtn.addEventListener("click", ()=> move(1));
  }

  // Prova social
  const proof = document.getElementById('social-proof');
  if(proof){
    const nomes = ["Eduarda","Mariana","Márcia","Ana","Rafaela","Camila","Joana","Beatriz","Larissa","Juliana","Sabrina","Isabela","Clara","Roberta","Vitória"];
    const cidades = ["Recife","São Paulo","Rio de Janeiro","Belo Horizonte","Salvador","Curitiba","Fortaleza","Brasília","Porto Alegre","Manaus","Florianópolis","Goiânia","Natal","João Pessoa","Maceió","Belém","Vitória","Campo Grande","Cuiabá","Aracaju"];
    function trocarProva(){
      const nome = nomes[Math.floor(Math.random()*nomes.length)];
      const cidade = cidades[Math.floor(Math.random()*cidades.length)];
      proof.textContent = `${nome} de ${cidade} acabou de comprar`;
    }
    setInterval(trocarProva, 3500);
  }
})();
</script> <section id="problema" class="py-14 md:py-20 bg-gradient-to-b from-pink-50 via-white to-pink-50 px-6"> <div class="max-w-5xl mx-auto space-y-12"> <!-- Headline --> <div class="text-center"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-4">
Esse é o verdadeiro motivo da sua PPK escurecer
        e você não sabia! 🚨
</h2> </div> <!-- Subtexto --> <div class="text-center max-w-3xl mx-auto"> <p class="text-black/70 text-base md:text-lg leading-relaxed">
A causa invisível é a hiperpigmentação íntima (escurecimento) — quando o corpo produz melanina em excesso para se defender de:
</p> </div> <!-- Lista de causas --> <div class="max-w-2xl mx-auto space-y-4 text-base md:text-lg text-black/80"> <div class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>Roupas apertadas e depilação que irritam a pele</p> </div> <div class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>Alterações hormonais (gravidez, ciclo, menopausa)</p> </div> <div class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>Produtos químicos agressivos que atacam a região</p> </div> </div> <!-- Problemas --> <div class="bg-white shadow-lg rounded-2xl p-8 md:p-10 border-l-4 border-pink-500 space-y-4"> <h3 class="font-semibold text-lg md:text-xl text-neutral-900">
E aqui está o problema:
</h3> <ul class="space-y-3 text-black/80 text-base md:text-lg"> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">❌</span> <p>Cremes comuns só “camuflam” a cor na superfície</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">❌</span> <p>Ácidos fortes causam ardência, descamação e até pioram a sensibilidade</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">❌</span> <p>O escuro volta logo depois</p> </li> </ul> </div> </div> </section> <section id="beneficios" class="py-14 md:py-20 bg-gradient-to-b from-white via-pink-50/30 to-white px-6"> <div class="max-w-6xl mx-auto space-y-10"> <!-- Headline --> <div class="text-center max-w-3xl mx-auto"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-6">
Por isso criamos o <span class="text-pink-600">PPClear</span>:  
        O único clareador íntimo com tecnologia Nano Glow Íntimo,
        que age direto na origem do escurecimento.
</h2> </div> <!-- Subtexto --> <div class="text-center max-w-3xl mx-auto"> <p class="text-base md:text-lg text-black/70 leading-relaxed">
O que o PPClear faz de diferente:
</p> </div> <!-- Diferenciais principais --> <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center"> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
1. Ataca a melanina na raiz
</h3> <p class="text-base md:text-lg text-black/70">
Clareamento de verdade, não efeito passageiro.
</p> </div> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
2. Hidrata profundamente
</h3> <p class="text-base md:text-lg text-black/70">
Pele macia, uniforme e confortável.
</p> </div> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
3. Zero agressão
</h3> <p class="text-base md:text-lg text-black/70">
Nada de ácidos que queimam ou ardem sua região íntima.
</p> </div> </div> <!-- Subseção de benefícios --> <div class="max-w-4xl mx-auto space-y-8"> <h3 class="text-2xl md:text-3xl font-bold text-neutral-900 text-center">
Com o <span class="text-pink-600">PPClear</span> você descobrirá:
</h3> <ul class="space-y-4 text-base md:text-lg text-black/80"> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>
O segredo por trás da “PPK de porcelana” que antes só famosas conseguiam em clínicas caras.
</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>
Como clarear sem descamar, sem arder e sem parar sua rotina. Basta 2 minutos, uma passada por noite e os resultados vêm em menos de 15 dias.
</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>
O efeito colateral positivo que ninguém espera: pele mais firme e sedosa em poucas semanas.
</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>
Por que o <span class="text-pink-600 font-semibold">PPClear</span> é chamado de “autoestima em gotas” pelas clientes.
</p> </li> <li class="flex items-start space-x-3"> <span class="text-pink-600 text-base md:text-lg">•</span> <p>
Como usar em apenas 2 minutos à noite e deixar a ciência fazer o resto.
</p> </li> </ul> </div> </div> </section> <section id="ingredientes" class="py-14 md:py-20 bg-gradient-to-b from-pink-50 via-white to-pink-50 px-6"> <div class="max-w-6xl mx-auto space-y-10"> <!-- Headline --> <div class="text-center max-w-3xl mx-auto"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-6">
Por que o <span class="text-pink-600">PPClear</span> é o Autoestima em gotas?
</h2> </div> <!-- Subtexto --> <div class="text-center max-w-3xl mx-auto"> <p class="text-base md:text-lg text-black/70 leading-relaxed">
Enquanto clareadores comuns só “pintam” a superfície da pele e somem em poucos dias,
        o <span class="text-pink-600 font-semibold">PPClear</span> foi desenvolvido com a exclusiva fórmula
<strong>Nano Glow Íntimo</strong> que combina ciência + cuidado íntimo em um só sérum:
</p> </div> <!-- Ingredientes --> <div class="grid grid-cols-1 md:grid-cols-2 gap-8"> <!-- Vitamina C --> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
Vitamina C Nanoencapsulada
</h3> <p class="text-base md:text-lg text-black/70">
Capaz de “desligar o interruptor” da melanina em excesso, revelando o tom natural escondido da sua PPK.
</p> </div> <!-- Ácido Hialurônico --> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
Ácido Hialurônico Puro
</h3> <p class="text-base md:text-lg text-black/70">
Hidratação profunda e firmeza imediata. O mesmo ativo usado em procedimentos caríssimos de estética, agora em uma gota noturna.
</p> </div> <!-- Niacinamida --> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
Niacinamida de Alta Potência
</h3> <p class="text-base md:text-lg text-black/70">
Uniformiza a cor e dá aspecto de pele de porcelana.
</p> </div> <!-- Pantenol --> <div class="bg-white shadow-md rounded-2xl p-6 hover:shadow-lg transition"> <h3 class="text-lg md:text-xl font-bold text-pink-600 mb-2">
Pantenol Restaurador
</h3> <p class="text-base md:text-lg text-black/70">
Ação calmante que protege contra irritações e atritos futuros.
</p> </div> </div> </div> </section> <section id="depoimentos" class="py-14 md:py-20 bg-gradient-to-b from-white via-pink-50/30 to-white px-6"> <div class="max-w-7xl mx-auto space-y-10"> <!-- Headline --> <div class="text-center max-w-3xl mx-auto"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-6">
O que as clientes estão dizendo
</h2> <p class="text-base md:text-lg text-black/70">
Resultados reais de quem já usou o <span class="text-pink-600 font-semibold">PPClear</span>.
</p> </div> <!-- Grid de depoimentos --> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"> <!-- Depoimento 1 --> <div class="bg-white shadow-lg rounded-2xl p-6 flex flex-col"> <img src="/ppclear/comprador1.webp" alt="Juliana usando PPKare" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <div class="flex mb-3 text-yellow-400 text-lg md:text-xl">★★★★★</div> <p class="text-base md:text-lg text-black/70 italic">
“Em 17 dias de uso já percebi diferença! Pele muito mais clara e macia, sem irritar. Recomendo!”
</p> <p class="mt-3 text-sm md:text-base font-semibold">— Juliana, 32 anos</p> </div> <!-- Depoimento 2 --> <div class="bg-white shadow-lg rounded-2xl p-6 flex flex-col"> <img src="/ppclear/comprador2.webp" alt="Camila mostrando produto" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <div class="flex mb-3 text-yellow-400 text-lg md:text-xl">★★★★★</div> <p class="text-base md:text-lg text-black/70 italic">
“Já testei outros produtos e nunca funcionou. O PPClear foi o único que clareou sem agredir.”
</p> <p class="mt-3 text-sm md:text-base font-semibold">— Camila, 28 anos</p> </div> <!-- Depoimento 3 --> <div class="bg-white shadow-lg rounded-2xl p-6 flex flex-col"> <img src="/ppclear/comprador5.webp" alt="Renata sorrindo com produto" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <div class="flex mb-3 text-yellow-400 text-lg md:text-xl">★★★★★</div> <p class="text-base md:text-lg text-black/70 italic">
“Eu não acreditava que ia ver resultado tão rápido… mas em menos de 15 dias minha pele já estava mais uniforme. Zero ardência, só conforto!”
</p> <p class="mt-3 text-sm md:text-base font-semibold">— Renata, 35 anos</p> </div> <!-- Depoimento 4 --> <div class="bg-white shadow-lg rounded-2xl p-6 flex flex-col"> <img src="/ppclear/comprador4.webp" alt="Aline depoimento" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <div class="flex mb-3 text-yellow-400 text-lg md:text-xl">★★★★★</div> <p class="text-base md:text-lg text-black/70 italic">
“Depois da gravidez fiquei incomodada com o escurecimento. O PPClear devolveu minha confiança, hoje me sinto muito melhor comigo mesma.”
</p> <p class="mt-3 text-sm md:text-base font-semibold">— Aline, 47 anos</p> </div> <!-- Depoimento 5 --> <div class="bg-white shadow-lg rounded-2xl p-6 flex flex-col"> <img src="/ppclear/comprador3.webp" alt="Patrícia depoimento" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <div class="flex mb-3 text-yellow-400 text-lg md:text-xl">★★★★★</div> <p class="text-base md:text-lg text-black/70 italic">
“Simples, prático e realmente eficaz. Passo toda noite e já sinto minha pele mais clara e super hidratada. Valeu cada centavo.”
</p> <p class="mt-3 text-sm md:text-base font-semibold">— Patrícia, 27 anos</p> </div> </div> </div> </section> <section id="comparacao" class="py-14 md:py-20 bg-gradient-to-b from-pink-50 via-white to-pink-50 px-4 md:px-6"> <div class="max-w-5xl mx-auto space-y-10"> <!-- Headline --> <div class="text-center"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900">
PPClear vs. Outras "Soluções"
</h2> </div> <!-- Desktop Tabela --> <div class="hidden md:block overflow-x-auto"> <table class="min-w-full bg-white shadow-xl rounded-xl overflow-hidden text-sm md:text-base"> <thead> <tr class="bg-pink-600 text-white"> <th class="p-4 text-left font-semibold">Critério</th> <th class="p-4 text-center font-semibold">PPClear</th> <th class="p-4 text-center font-semibold">Cremes</th> <th class="p-4 text-center font-semibold">Estéticos</th> </tr> </thead> <tbody class="text-gray-800"> <tr class="even:bg-pink-50/40"> <td class="p-4 font-medium">Resultados</td> <td class="p-4 text-center text-green-600 font-semibold">✅ 7-15 dias</td> <td class="p-4 text-center text-red-600">❌ Temporários</td> <td class="p-4 text-center text-red-600">❌ Meses</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-4 font-medium">Dor/Ardência</td> <td class="p-4 text-center text-green-600 font-semibold">✅ Zero</td> <td class="p-4 text-center text-red-600">❌ Frequente</td> <td class="p-4 text-center text-red-600">❌ Intensa</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-4 font-medium">Custo</td> <td class="p-4 text-center text-green-600 font-semibold">✅ R$ 197–297</td> <td class="p-4 text-center text-red-600">❌ R$ 300+</td> <td class="p-4 text-center text-red-600">❌ R$ 3.000+</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-4 font-medium">Praticidade</td> <td class="p-4 text-center text-green-600 font-semibold">✅ Casa, 2min</td> <td class="p-4 text-center text-red-600">❌ Complexo</td> <td class="p-4 text-center text-red-600">❌ Clínica</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-4 font-medium">Segurança</td> <td class="p-4 text-center text-green-600 font-semibold">✅ Testado</td> <td class="p-4 text-center text-red-600">❌ Duvidosa</td> <td class="p-4 text-center text-red-600">❌ Riscos</td> </tr> </tbody> </table> </div> <!-- Mobile Tabela Compacta --> <div class="md:hidden overflow-x-auto"> <table class="min-w-full bg-white shadow-md rounded-lg text-xs"> <thead> <tr class="bg-pink-600 text-white text-[13px]"> <th class="p-2 text-left font-semibold">Critério</th> <th class="p-2 text-center font-semibold">PPClear</th> <th class="p-2 text-center font-semibold">Cremes</th> <th class="p-2 text-center font-semibold">Estéticos</th> </tr> </thead> <tbody class="text-gray-800"> <tr class="even:bg-pink-50/40"> <td class="p-2 font-medium">Resultados</td> <td class="p-2 text-center text-green-600 font-semibold">✅</td> <td class="p-2 text-center text-red-600">❌</td> <td class="p-2 text-center text-red-600">❌</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-2 font-medium">Dor/Ardência</td> <td class="p-2 text-center text-green-600 font-semibold">✅</td> <td class="p-2 text-center text-red-600">❌</td> <td class="p-2 text-center text-red-600">❌</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-2 font-medium">Custo</td> <td class="p-2 text-center text-green-600 font-semibold">✅</td> <td class="p-2 text-center text-red-600">❌</td> <td class="p-2 text-center text-red-600">❌</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-2 font-medium">Praticidade</td> <td class="p-2 text-center text-green-600 font-semibold">✅</td> <td class="p-2 text-center text-red-600">❌</td> <td class="p-2 text-center text-red-600">❌</td> </tr> <tr class="even:bg-pink-50/40"> <td class="p-2 font-medium">Segurança</td> <td class="p-2 text-center text-green-600 font-semibold">✅</td> <td class="p-2 text-center text-red-600">❌</td> <td class="p-2 text-center text-red-600">❌</td> </tr> </tbody> </table> </div> <!-- CTA --> <div class="mt-6 text-center"> <a href="#oferta" class="inline-block rounded-xl bg-[#ed2b75] text-white font-semibold
                text-lg md:text-2xl px-7 md:px-10 py-3 shadow-lg transition transform hover:scale-105">
QUERO CLAREAR MINHA PPK
</a> </div> </div> </section> <section id="oferta" class="py-14 md:py-20 bg-gradient-to-b from-white via-pink-50/30 to-white px-6"> <div class="max-w-7xl mx-auto space-y-10"> <!-- Headline --> <div class="text-center"> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-4">
OFERTA RELÂMPAGO — Válida por 24h ⏰🔥
</h2> <p class="text-base md:text-lg text-black/70">
Aproveite agora e escolha o seu kit com desconto exclusivo:
</p> </div> <!-- Kits --> <div class="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch"> <!-- Kit 1 --> <div class="bg-white shadow-lg rounded-2xl p-8 flex flex-col text-center hover:shadow-xl transition order-2 md:order-1"> <img src="/ppclear/kit1.webp" alt="1 frasco PPKare" class="mx-auto w-40 md:w-50 mb-4" loading="lazy"> <h3 class="text-lg md:text-xl font-bold mb-3">1 PPClear</h3> <p class="text-gray-500 line-through text-sm md:text-base">R$ 297</p> <p class="text-xl md:text-2xl font-bold text-pink-600">R$ 197</p> <p class="text-sm md:text-base text-black/70 mb-4">(33% OFF)</p> <a href="https://app.trivvo.com.br/d/payment/4260C814F" class="mt-auto block bg-[#ed2b75] text-white text-center py-3 rounded-xl font-semibold transition text-base md:text-lg  hover:scale-105">
GARANTIR 1 UNIDADE
</a> </div> <!-- Kit 3 - Mais Vendido --> <div class="relative bg-gradient-to-b from-pink-100 to-white border-2 border-pink-600 shadow-2xl rounded-2xl p-8 flex flex-col text-center order-1 md:order-2 scale-105"> <!-- Badge --> <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-pink-600 text-white px-4 py-1 rounded-full text-xs md:text-sm font-bold shadow-md uppercase tracking-wide">
⭐ Mais Vendido
</div> <img src="/ppclear/kit3.webp" alt="3 frascos PPKare" class="mx-auto w-52 mb-4" loading="lazy"> <h3 class="text-lg md:text-xl font-bold mb-3 mt-2">3 PPClear</h3> <p class="text-gray-500 line-through text-sm md:text-base">R$ 597</p> <p class="text-xl md:text-2xl font-bold text-pink-600">R$ 397</p> <p class="text-sm md:text-base text-black/70 mb-4">(33% OFF)</p> <a href="https://app.trivvo.com.br/d/payment/426225566" class="mt-auto block bg-[#ed2b75] text-white text-center py-3 rounded-xl font-semibold transition hover:scale-105 text-base md:text-lg">
GARANTIR 3 UNIDADES
</a> </div> <!-- Kit 2 --> <div class="bg-white shadow-lg rounded-2xl p-8 flex flex-col text-center hover:shadow-xl transition order-3 md:order-3"> <img src="/ppclear/kit2.webp" alt="2 frascos PPKare" class="mx-auto w-48 mb-4" loading="lazy"> <h3 class="text-lg md:text-xl font-bold mb-3">2 PPClear</h3> <p class="text-gray-500 line-through text-sm md:text-base">R$ 397</p> <p class="text-xl md:text-2xl font-bold text-pink-600">R$ 297</p> <p class="text-sm md:text-base text-black/70 mb-4">(25% OFF)</p> <a href="https://app.trivvo.com.br/d/payment/4261AF81A" class="mt-auto block bg-[#ed2b75] text-white text-center py-3 rounded-xl font-semibold  hover:scale-105 transition text-base md:text-lg ">
GARANTIR 2 UNIDADES
</a> </div> </div> <!-- Garantias --> <div class="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mt-12"> <div class="flex items-center md:flex-col md:space-y-2 space-x-3 md:space-x-0 text-left md:text-center"> <span class="text-green-500 text-2xl">✅</span> <p class="text-base md:text-lg font-medium">
Frete GRÁTIS em todo Brasil
</p> </div> <div class="flex items-center md:flex-col md:space-y-2 space-x-3 md:space-x-0 text-left md:text-center"> <span class="text-green-500 text-2xl">✅</span> <p class="text-base md:text-lg font-medium">Garantia de 7 dias</p> </div> <div class="flex items-center md:flex-col md:space-y-2 space-x-3 md:space-x-0 text-left md:text-center"> <span class="text-green-500 text-2xl">✅</span> <p class="text-base md:text-lg font-medium">Pagamento seguro</p> </div> </div> <!-- Extra --> <div class="text-center text-black/80 mt-6"> <p class="font-semibold text-base md:text-lg">
Frete Grátis + Bônus Exclusivo nos kits!
</p> </div> <!-- CTA --> <div class="mt-6 text-center"> <a href="#oferta" class="inline-block rounded-xl bg-[#ed2b75] text-white font-semibold
                text-lg md:text-2xl px-7 md:px-10 py-3 shadow-lg transition transform hover:scale-105">
QUERO O PPClear COM DESCONTO
</a> </div> </div> </section> <section id="garantia" class="py-14 md:py-20 bg-gradient-to-b from-pink-50 via-white to-pink-50 px-6"> <div class="max-w-5xl mx-auto text-center space-y-8 md:space-y-10"> <!-- Headline --> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900">
Você está 100% segura.
</h2> <!-- Subtexto --> <p class="text-base md:text-lg text-black/70 max-w-2xl mx-auto leading-relaxed">
Use o <span class="text-pink-600 font-semibold">PPClear</span> por até 7 dias.
      Se não notar melhora, devolvemos todo o seu dinheiro.
<strong>Sem perguntas, sem enrolação.</strong> </p> <!-- Imagem de garantia --> <div class="flex justify-center"> <img src="/selo.webp" alt="Selo de garantia 30 dias" class="w-42 md:w-58 h-auto" loading="lazy"> </div> </div> </section> <section id="modo-de-uso" class="py-14 md:py-18 bg-gradient-to-b from-white via-pink-50/30 to-white px-6"> <div class="max-w-5xl mx-auto space-y-10"> <!-- Lista de instruções --> <div class="space-y-6"> <ol class="list-decimal list-inside space-y-4 text-base md:text-lg text-black/80"> <li>Lave bem a região antes de dormir.</li> <li>
Aplique <strong class="text-pink-600">1 gota de cada lado</strong> da
          vulva (uso externo).
</li> <li>Massageie suavemente até completa absorção.</li> </ol> <!-- Aviso --> <div class="flex items-center space-x-3 mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg"> <span class="text-yellow-500 text-2xl">⚠️</span> <p class="text-base md:text-lg text-black/80 font-medium">
Não aplicar internamente.
</p> </div> </div> <!-- Título galeria --> <div class="text-center mt-12"> <h3 class="text-xl md:text-2xl font-bold uppercase tracking-wide text-yellow-500">
Como utilizar o sérum clareador?
</h3> </div> <!-- Galeria de imagens --> <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8 text-center"> <!-- Card 1 --> <div class="bg-white shadow-md rounded-xl overflow-hidden p-4"> <img src="/ppclear/Tuto1.webp" alt="Passo 1" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <p class="text-sm md:text-base text-black/80">
À noite, após a região estar completamente limpa.
</p> </div> <!-- Card 2 --> <div class="bg-white shadow-md rounded-xl overflow-hidden p-4"> <img src="/ppclear/Tuto3.webp" alt="Passo 2" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <p class="text-sm md:text-base text-black/80">
Aplique uma gota em cada lado da vulva.
</p> </div> <!-- Card 3 --> <div class="bg-white shadow-md rounded-xl overflow-hidden p-4"> <img src="/ppclear/Tuto2.webp" alt="Passo 3" class="w-full h-56 object-cover rounded-lg mb-4" loading="lazy"> <p class="text-sm md:text-base text-black/80">
Massageie com movimentos circulares. Não aplique na área interna.
</p> </div> </div> </div> </section> <section id="faq" class="py-14 md:py-20 bg-gradient-to-b from-white via-pink-50/30 to-white px-6"> <div class="max-w-5xl mx-auto space-y-10"> <!-- FAQ --> <div> <h2 class="font-serif text-2xl md:text-4xl font-bold text-neutral-900 mb-10 text-center">
Perguntas Frequentes
</h2> <div class="space-y-8"> <!-- Q1 --> <div> <p class="font-semibold text-lg md:text-xl text-pink-600 flex items-center gap-2">
❓ Em quanto tempo vou me sentir confiante de novo?
</p> <p class="text-black/80 mt-2 text-base md:text-lg">
A maioria das nossas clientes relata aumento na autoestima já na
            primeira semana. Resultados visuais aparecem entre 7–15 dias.
</p> </div> <!-- Q2 --> <div> <p class="font-semibold text-lg md:text-xl text-pink-600 flex items-center gap-2">
❓ Posso usar em outras partes do corpo?
</p> <p class="text-black/80 mt-2 text-base md:text-lg">
Sim! Virilha, axilas, glúteos, joelhos. Onde você quiser se sentir
            perfeita.
</p> </div> <!-- Q3 --> <div> <p class="font-semibold text-lg md:text-xl text-pink-600 flex items-center gap-2">
❓ Vai interferir na minha sensibilidade?
</p> <p class="text-black/80 mt-2 text-base md:text-lg">
Pelo contrário! O <span class="text-pink-600 font-semibold">PPClear</span>
hidrata profundamente, deixando tudo mais macio e confortável.
</p> </div> <!-- Q4 --> <div> <p class="font-semibold text-lg md:text-xl text-pink-600 flex items-center gap-2">
❓ É seguro usar durante a menstruação?
</p> <p class="text-black/80 mt-2 text-base md:text-lg">
Totalmente seguro. Nossa fórmula respeita o pH natural da região.
</p> </div> <!-- Q5 --> <div> <p class="font-semibold text-lg md:text-xl text-pink-600 flex items-center gap-2">
❓ Meu parceiro vai notar a diferença?
</p> <p class="text-black/80 mt-2 text-base md:text-lg">
Prepare-se para os elogios. Não só pela aparência, mas pela sua nova
            confiança que vai irradiar.
</p> </div> </div> </div> <!-- Bloco de confiança --> <div class="text-center space-y-6"> <p class="text-black/80 text-base md:text-lg"> <span class="text-yellow-600">🔒</span>
Compra 100% Segura | Entrega Expressa | Garantia Blindada
</p> <p class="italic text-black/70 max-w-2xl mx-auto text-base md:text-lg">
“Sua autoestima não pode esperar. Sua transformação começa hoje.”
</p> </div> <!-- Rodapé final --> <div class="border-t pt-8 text-center space-y-4"> <p class="flex justify-center items-center gap-2 text-black/80 text-base md:text-lg"> <span class="text-pink-600">📞</span> <strong>Dúvidas? WhatsApp:</strong> (11) 95168-4760
</p> <p class="flex justify-center items-center gap-2 text-black/80 text-base md:text-lg"> <span class="text-blue-500">🌐</span>
Empresa brasileira há 5 anos transformando vidas
</p> <p class="flex justify-center items-center gap-2 text-black/80 text-base md:text-lg"> <span class="text-green-600">🏆</span>
Mais de 20.000 clientes satisfeitas
</p> </div> </div> </section> <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"57071c77bb864a8aad56b86b20a4b0ea","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body></html>